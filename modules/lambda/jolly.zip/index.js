const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event, context) => {
  
  console.log('AWSrequestID =', context.awsRequestId);
  console.log('event' + JSON.stringify(event));
  
  let body;
  let statusCode = 200;
  const headers = {
    "Content-Type": "application/json",
     "Access-Control-Allow-Origin": "*" 
  };

  try {
    let route = event.httpMethod + " " + event.resource;
    let requestJSON;
    console.log("route : " + route)
 
    }
  } catch (err) {
    console.log(err);
    statusCode = 500;
    body = err.message;
  } finally {
    body = JSON.stringify(body);
  }

  return {
    statusCode,
    body,
    headers
    
  };
};
